Khanh Mail Checker V38 OnlineReady

Đây là file update online mẫu.
Upload file zip này lên hosting/GitHub/VPS, rồi đặt link trong manifest.json.

Nếu bạn đang dùng V37, tool sẽ thấy V38 là bản mới hơn và cho update.
